--MPD Textures by CAPNCOKE
livery = 
{

        {"F-18C-mirror",            0,                  "mirrors", true};
        {"f18c_cpt03-instr",	    DIFFUSE,	        "f18c_cpt-tex03", false};
        {"f18c_cpt03-instr",        13,                 "f18c_cpt-tex03_roughmet", false};
        {"f18c_mdi_r",	            DIFFUSE,	        "f18c_mdi_r", false};
        {"f18c_mdi_r_additive",	    DIFFUSE,	        "f18c_mdi_r", false};
        {"f18c_mdi_r_additive",	    SELF_ILLUMINATION,	"empty", false};
        {"f18c_mdi_l",	            DIFFUSE,	        "f18c_mdi_l", false};
        {"f18c_mdi_l_additive",	    DIFFUSE,	        "f18c_mdi_l", false};
        {"f18c_mdi_l_additive",	    SELF_ILLUMINATION,	"empty", false};
        {"f18c_cpt-displayglass",	DIFFUSE,	        "f18c_cpt-displayglass_refl", false};
        {"f18c_cpt-displayglass",	14,	                "f18c_cpt-displayglass-dif", false};
        {"f18c_cpt-displayglass",   13,                 "f18c_cpt-displayglass_refl_Roughmet", false};

    
    ----REFERENCES FOR TEXTURE MATERIAL PROPERTIES----
    ----Why does this look so neat you say?! Well I was god damn bored asf making this MPD mod----

    -- {"F-18C-mirror",             0,                  "mirrors", true};
    -- {"f18c_cpt03-instr",         0,                  "f18c_cpt-tex03", false};
    -- {"f18c_cpt03-instr",         13,                 "f18c_cpt-tex03_roughmet", false};
    -- {"f18c_mdi_l",               0,                  "f18c_mdi_l", false};
    -- {"f18c_mdi_l_additive",	    0,                  "f18c_mdi_l", false};
    -- {"f18c_mdi_l_additive",	    8,                  "empty", false};
    -- {"f18c_mdi_r",               0,                  "f18c_mdi_r", false};
    -- {"f18c_mdi_r_additive",	    0,                  "f18c_mdi_r", false};
    -- {"f18c_mdi_r_additive",	    8,                  "empty", false};
    -- {"f18c_cpt-displayglass",    0,                  "f18c_cpt-displayglass_refl", false};
    -- {"f18c_cpt-displayglass",    14,                 "f18c_cpt-displayglass-dif", false};
    -- {"f18c_cpt-displayglass_cl", 0,                  "f18c_cpt-displayglass_cl_refl", false};
    -- {"f18c_cpt-displayglass_cl", 14,                 "f18c_cpt-displayglass-dif", false};
    -- {"f18c_cpt-displayglass",    13,                 "f18c_cpt-displayglass_refl_Roughmet", false};
    -- 0 Diffuse, 8 Self Illumination, 13 Roughmet, 14 glass diffuse?
}

-- set true to enable bake (render) to a dedicated cockpit texture
local bakeToCockpitTexture = false

if bakeToCockpitTexture == true then
	livery[#livery + 1] = {"f18c_mdi_l_additive", DIFFUSE, "LMDI_Bake", true} -- Left MDI picture
	livery[#livery + 1] = {"f18c_mdi_r_additive", DIFFUSE, "RMDI_Bake", true} -- Right MDI picture
end