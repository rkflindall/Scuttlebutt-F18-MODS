For LCD Textures (OPTIONAL but RECOMMENDED), Drag "Cockpit_F-18C" folder to C:\Users\YourUserName\Saved Games\dcs or dcs.openbeta\Liveries


To enable MPD textures, head to Ingame Settings>Special Options>F/A-18C and select Modern MPD in Customized Cockpit. (Does not break IC).
