Open either folder for desired aircraft "For FA-18C" or "For CJS FA-18EF Mod" and drag contents to your mod manager mod folder.

"MPD Textures" goes to your savegame folder in Liveries.

Check the forum topic for detailed instructions.]
https://forum.dcs.world/topic/347416-fa-18c-modern-mpd-v-2137-updated-1172024/