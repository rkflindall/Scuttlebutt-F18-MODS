--REALISTIC HUD--
materials["HUD_GLOW_MATERIAL"]			= {2, 255, 20, 0.1} -- HUD Glow			--Alpha of 0.2 seems realistic enough where minor adjustment is needed to remove the glow, while still being visible in certain light conditions.

-- --FADING HUD EFFECT OFFCENTER
-- materials["HUD_TIME"]							= {2, 255, 20, 5}
-- fonts["HUD_TIME"] 					= {fontdescription["font_stroke_MDG"], 10, materials["HUD_TIME"]}

-- materials["HUD_BANK_TICKS"]                     = {2, 255, 20, 100}

