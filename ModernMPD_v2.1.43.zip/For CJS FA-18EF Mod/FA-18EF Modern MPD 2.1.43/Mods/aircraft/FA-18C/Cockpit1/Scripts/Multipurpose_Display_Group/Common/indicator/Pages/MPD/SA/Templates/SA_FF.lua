dofile(LockOn_Options.script_path.."Multipurpose_Display_Group/Common/indicator/Pages/MPD/MPD_page_defs.lua")
dofile(LockOn_Options.script_path.."Multipurpose_Display_Group/Common/indicator/MDG_strokesDefs.lua")
default_material = "MDG_GREEN"
local SA_FF_Element_Root = addPlaceholder("SA_ff", nil, nil, {{"MPD_SA_SetSymbolPosition", DYNAMIC_DATA.SA_FF}})

local SA_FF_Element_Outlined = addPlaceholder(SA_FF_Element_Root.name.."_Outlined", nil, SA_FF_Element_Root.name, {{"MPD_SA_DisableDrawOutlinedOnDDI"}})
stroke_thickness = DMC_outline_thickness
stroke_fuzziness = DMC_outline_fuzziness
stroke_font = "font_MPD_DMC_outline"
SA_FF_Symbol(SA_FF_Element_Outlined.name, {"MPD_SA_SetCourse", DYNAMIC_DATA.SA_FF, 20}, 1)

local SA_FF_Element_DMC = addPlaceholder(SA_FF_Element_Root.name.."_DMC", nil, SA_FF_Element_Root.name)
stroke_thickness = DMC_stroke_thickness
stroke_fuzziness = DMC_stroke_fuzziness
stroke_font = "font_MPD_DMC_main"
SA_FF_Symbol(SA_FF_Element_DMC.name, {"MPD_SA_SetCourse", DYNAMIC_DATA.SA_FF, 20}, 0)

local SA_TUC_FF_Data_Root = addPlaceholder("SA_TUC_FF_Data_Root", {0, 0}, SA_FF_Element_Root.name, {{"TDC_assignedDisplay"}, {"MPD_SA_TUCDataPosition", DYNAMIC_DATA.SA_FF}})
addStrokeText("TDC_FF_MaxAltitude", nil, STROKE_FNT_DFLT_100, "RightCenter", {-50, 0}, SA_TUC_FF_Data_Root.name, {{"MPD_SA_TUCAltitude_Max"}, {"MPD_SA_FF_Color", 0}})
addStrokeText("TDC_FF_RelativeAltitude", nil, STROKE_FNT_DFLT_100, "LeftCenter", {50, 0}, SA_TUC_FF_Data_Root.name, {{"MPD_SA_TUCAltitude_Relative"}, {"MPD_SA_FF_Color", 0}})