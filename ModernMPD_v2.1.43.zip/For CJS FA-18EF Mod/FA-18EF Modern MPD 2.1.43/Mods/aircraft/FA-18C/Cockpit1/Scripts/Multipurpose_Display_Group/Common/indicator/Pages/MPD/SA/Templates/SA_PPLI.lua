dofile(LockOn_Options.script_path.."Multipurpose_Display_Group/Common/indicator/Pages/MPD/MPD_page_defs.lua")
dofile(LockOn_Options.script_path.."Multipurpose_Display_Group/Common/indicator/MDG_strokesDefs.lua")
default_material = "MDG_GREEN"
local SA_PPLI_Element_Root = addPlaceholder("SA_ppli", nil, nil, {{"MPD_SA_SetSymbolPosition", DYNAMIC_DATA.SA_PPLI}})

local SA_PPLI_Element_Outlined = addPlaceholder(SA_PPLI_Element_Root.name.."_Outlined", nil, SA_PPLI_Element_Root.name, {{"MPD_SA_DisableDrawOutlinedOnDDI"}})
stroke_thickness = DMC_outline_thickness
stroke_fuzziness = DMC_outline_fuzziness
stroke_font = "font_MPD_DMC_outline"
SA_PPLI_Symbol(SA_PPLI_Element_Outlined.name, {"MPD_SA_SetCourse", DYNAMIC_DATA.SA_PPLI, 20}, 1, true)

local SA_PPLI_Element_DMC = addPlaceholder(SA_PPLI_Element_Root.name.."_DMC", nil, SA_PPLI_Element_Root.name)
stroke_thickness = DMC_stroke_thickness
stroke_fuzziness = DMC_stroke_fuzziness
stroke_font = "font_MPD_DMC_main"
SA_PPLI_Symbol(SA_PPLI_Element_DMC.name, {"MPD_SA_SetCourse", DYNAMIC_DATA.SA_PPLI, 20}, 0, true)

local SA_TUC_PPLI_Data_Root = addPlaceholder("SA_TUC_PPLI_Data_Root", {0, 0}, SA_PPLI_Element_Root.name, {{"TDC_assignedDisplay"}, {"MPD_SA_TUCDataPosition", DYNAMIC_DATA.SA_PPLI}})
addStrokeText("TDC_PPLI_MaxAltitude", nil, STROKE_FNT_DFLT_100, "RightCenter", {-50, 0}, SA_TUC_PPLI_Data_Root.name, {{"MPD_SA_TUCAltitude_Max"}, {"MPD_SA_PPLI_Color", 0}})
addStrokeText("TDC_PPLI_RelativeAltitude", nil, STROKE_FNT_DFLT_100, "LeftCenter", {50, 0}, SA_TUC_PPLI_Data_Root.name, {{"MPD_SA_TUCAltitude_Relative"}, {"MPD_SA_PPLI_Color", 0}})