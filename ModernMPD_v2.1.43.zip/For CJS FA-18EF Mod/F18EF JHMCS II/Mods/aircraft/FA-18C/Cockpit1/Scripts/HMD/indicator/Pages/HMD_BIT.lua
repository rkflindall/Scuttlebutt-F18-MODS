dofile(LockOn_Options.script_path.."HMD/indicator/HMD_Page_defs.lua")
stroke_thickness = 0.8
stroke_fuzziness = 0.5

addStrokeText("BIT_TEXT", "IN TEST", STROKE_FNT_DFLT_120, "CenterCenter", {0,0}, nil, {{"HMD_StandbyFlash"}})