--USER CUSTOMIZATION--
--USE RGB COLOR CODES TO DEFINE DESIRED COLORS. KEEP ALPHA VALUE (COLUMN 4) AS IS UNLESS YOU KNOW WHAT YOU ARE DOING.

materials["HSI_aircraftsymbol"]					= {0,200,255,400}                 --AIRCRAFT SYMBOL CROSS in HSI/SA/EW/etc      {0,200,255,350}         -- LIGHT Blue
materials["HSI_wptdashline"]			        = {255, 0, 255, 450}            --Waypoint dash line when in sequence mode      {255, 0, 255, 450}      --Purple


materials["RDR_amraam"]					        = {255, 0, 255, 450}            --AMRAAM missile symbol TTA and TTI             {255, 0, 255, 450}      --Purple

materials["MDG_GREEN"]					        = {94,202,0,350}                --Friendly green PPLI/Datalink                  {94,202,0,350}          --Green
materials["MDG_CYAN"]					        = {0,255,255,350}               --Friendly donated by surveillance              {0,255,255,350}         --Cyan

materials["ADVISORY"] 		                    = {255, 240, 0, 350}            --ADVISORY/CAUTION font color                   {255, 240, 0, 350}      --Yellow


--END OF USER CUSTOMIZATION--


--HUD
materials["HUD_TIME"]							= {2, 255, 20, 385}
fonts["HUD_TIME"] 					= {fontdescription["font_stroke_MDG"], 10, materials["HUD_TIME"]}

materials["HUD_BANK_TICKS"]                     = {2, 255, 20, 385}


