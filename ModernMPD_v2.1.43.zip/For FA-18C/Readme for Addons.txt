Installation:

Drag desired mod addon folder to your mod manager. Activate after activating F18 Modern MPD mod.

Realistic Hud:
Adds realistic constraints and hud projection glow.

JHMCS II:
Introduces color to HMD. Hostile units such as airborne threats and SAM now shows in red. Unknown shows in yellow. Members in Cyan. Friendlies as default green.
WIP. Sources are from Elbeit Systems JHMCS II promotional materials.